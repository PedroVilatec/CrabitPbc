Make sure you have the latest version of ESP8266MQTTMesh before reporting an issue.

### Please Provide the following information:
- ESP8266MQTTMesh version:
- AsyncMQTTClient version:
- ESPAsyncTCP version:
- ESP8266 Core version:

**If you are you using platformio or Arduino, which one?**


**Description of problem:**


